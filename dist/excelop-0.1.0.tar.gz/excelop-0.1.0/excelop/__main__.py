from excelop import ExcelOp


if __name__ == '__main__':
    excelop = ExcelOp("hello.xlsx")
    excelop.save()
